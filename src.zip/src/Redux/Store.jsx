import {createStore,combineReducers} from "redux"
import { EmployeReducer } from "./Reducer/EmployeReducer"

// const RootStore=combineReducers({
//     emp:EmployeReducer
// })



let store=createStore(EmployeReducer)
export default store
