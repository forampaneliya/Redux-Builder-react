import { EMPOYEE } from "../ActionTypes";

export const EmployeeAction=(data)=>{
    return{
        type:EMPOYEE,
        payload:data
    }
}