import { EMPOYEE } from "../ActionTypes";


let allget = JSON.parse(localStorage.getItem("employ"))
const initialValue = {
    employee: allget ? allget : []
}


export const EmployeReducer = (state = initialValue, action) => {
    switch (action.type) {
        case EMPOYEE: {
            let dataa = [...state.employee, action.payload]
            localStorage.setItem("employ", JSON.stringify(dataa))
            return { ...state, employee: dataa }
        }
        default: return state

    }
}