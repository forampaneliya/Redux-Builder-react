import { useSelector } from "react-redux"

function ShowEmployee()
{

    let list=useSelector((state)=>console.log(state.employee))
    
    return(
        <>
        <table border={1} align="center">
            <th>Username</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Address</th>
      {/* {
        list.map((v,i)=>{
            return(
                <>
                <tr>
                    <td>{v.username}</td>
                    <td>{v.phone}</td>
                    <td>{v.email}</td>
                    <td>{v.address}</td>

                </tr>
                </>
            )
        })
      } */}
      </table>

        </>
    )
}
export default ShowEmployee